var express = require('express');
var request = require('request');
var iconv = require('iconv-lite');
var cheerio = require('cheerio');
var router = express.Router();
var headers = {  
  'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.65 Safari/537.36',
  'cache-control': 'no-cache',
  'postman-token': 'a0c7f1f3-1750-2dbd-4c35-fe5d3017ca3e'
}
var options = { method: 'GET',
  url: 'http://images.google.com.tw/searchbyimage',
  qs: { image_url: 'i.imgur.com/ZkAK6JA.jpg' },
  headers: 
   { 'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.65 Safari/537.36',
     'postman-token': '74a50f3b-5cde-6859-8277-83d9e4751b5c',
     'cache-control': 'no-cache' },
  gzip:true,
  async: true,
  crossDomain: true//,
  };
/* GEtrT home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/google', function(req, res, next) {
  request(options, function(e,r,b) {
    options.qs.image_url = req.query.img;
    console.log(req.query.img);
    var html = iconv.decode(b, 'gb2312');
    var $ = cheerio.load(html, {decodeEntities: false});
    var result =  $('a._gUb').text();
    if(!e){
      console.log(result);
      res.send(result);
      //res.send( iconv.decode(b, 'gb2312'));
    }
  });
  //res.render('index', { title: 'Express' });
});



module.exports = router;
